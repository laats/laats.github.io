# -*-Python-*-
################################################################################
#
# File:         __init__.py
# RCS:          $Header: $
# Description:  
# Author:       Staal Vinterbo
# Created:      Wed May  8 21:50:50 2013
# Modified:     Sun Jun 23 15:40:42 2013 (Staal Vinterbo) staal@mats
# Language:     Python
# Package:      N/A
# Status:       Experimental
#
# (c) Copyright 2013, Staal Vinterbo, all rights reserved.
#
################################################################################


from version import Version
import docstring
import qp, ra, cl
__doc__ = docstring.__doc__

