# -*-Python-*-
################################################################################
#
# File:         version.py
# RCS:          $Header: $
# Description:  The version number for dpdq
# Author:       Staal Vinterbo
# Created:      Wed Jun 12 23:24:53 2013
# Modified:     Thu May 18 12:06:17 2017 (Staal Vinterbo) staal@klump
# Language:     Python
# Package:      N/A
# Status:       Experimental
#
# (c) Copyright 2013, Staal Vinterbo, all rights reserved.
#
# version.py is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# version.py is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with version.py; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#
################################################################################

Version = '0.28'
