################################################################################
#
# File:         mda.r
# RCS:          $Header: $
# Description:  
# Author:       Staal Vinterbo
# Created:      Fri Mar 16 17:29:40 2012
# Modified:     Mon Jul  9 11:43:30 2012 (Staal Vinterbo) staal@dink
# Language:     ESS[S]
# Package:      N/A
# Status:       Experimental
#
# (c) Copyright 2012, Staal Vinterbo, all rights reserved.
# mda.r is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# mda.r is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with mda.r; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#
#
################################################################################

pairs = function(h, x = 0, y = 0){
  if (length(h) == 0) return(x)
  n = head(h, 1)
  pairs(tail(h, -1), x + y*n, y + n)
}

mda.r = function(f, m, tau=0.01){
  partition = function(indexlist, values)
    tapply(indexlist, values, list)

  refine = function(part, attribute)
    unlist(lapply(part, function(il) partition(il, attribute[il])),
           recursive=FALSE)

  hist = function(indexlist, values)
    apply(table(indexlist, values), 2, sum)

  leftover = function(part, attribute)
    sum(sapply(part,
               function(il) pairs(hist(il, attribute[il]))))
  
  mda.rec = function(m, f, b, C, A, S, last.leftover){
    if(length(A) == 0 || leftover(C, m[,f]) <= b) return(S)
    lovers = sapply(A, function(i) leftover(refine(C, m[,i]), m[,f]))
    a = which.min(lovers)
    if (last.leftover <= lovers[a]) return (S)  
    mda.rec(m, f, b, refine(C, m[,A[a]]), A[-a], c(S,A[a]), lovers[a])
  }
  
  mda.rec(m, f, round(tau * leftover(list(1:nrow(m)), m[,f])),
          list(1:nrow(m)), (1:ncol(m))[-f], c(), Inf)
}
