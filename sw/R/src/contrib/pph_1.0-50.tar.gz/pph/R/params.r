################################################################################
#
# File:         params.r
# RCS:          $Header: $
# Description:  
# Author:       Staal Vinterbo
# Created:      Fri Mar 16 16:53:11 2012
# Modified:     Mon Jul  9 11:42:22 2012 (Staal Vinterbo) staal@dink
# Language:     ESS[S]
# Package:      N/A
# Status:       Experimental
#
# (c) Copyright 2012, Staal Vinterbo, all rights reserved.
#
# params.r is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# params.r is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with params.r; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#
#
################################################################################

#source('disc.r')
#source('mda.r')

####### k
getpis = function(bw, n = 100, m=100) 
  apply(Reduce(rbind,
               lapply(1:m,
                      function(i) table(vdisc(v01(rnorm(n)), bw))/n)),
        2, mean)


defk = function(data, tau=0.1, target=ncol(data)) {
  gend.norm = function(q=3, bw=0.5, m=10, n=1000) {
    bw = max(bw, 0.2) # don't discretize too much
    probs = getpis(bw)
    Reduce(cbind,
           c(list(target=sample(1:q, n, prob=runif(q), replace=TRUE)),
             lapply(1:m,
                    function(i) sample(1:(1/bw), n, prob=probs, replace=TRUE))))
  }
  findk.norm = function(q, n, d, tau=0.05, ek=d) 
    return(length(mda.r(1, gend.norm(q, bw=getbw.fun(n,ek), m=d, n=n), tau)))
  
  n = nrow(data)
  m = ncol(data)
  q = length(unique(data[[target]]))
  findk.norm(q, n, m-1, tau=tau)
}

####### epsilon_p

# use "normally" distributed data model.
peps = function(data, k = defk(data), tau=0.1, B=1){
  findep = function(q, n, d, k=3, B=1, tau=0.05, minv=0.1, maxv=0.9){
    prs = q*(q-1)/2 * round((n/q))^2
    eps = (n*B*k^2*log(d-1))/(tau * prs)
    list(v = max(min(maxv, eps), minv), eps=eps)
  }
  findep(length(unique(data[[ncol(data)]])),nrow(data), ncol(data), k, tau=tau, B=B)
}

####### epsilon_h

heps = function(data, k = defk(data), p=0.95, eps=1){
  hxest = function(q, n, k) {
    bw = getbw.fun(n, k)
    x = getpis(bw)
    peq = (sum(x^2))^k
    n/q*peq
  }
  findeh = function(q, n, k, p=0.95, A=0.5, eps=1) {
                                        #tau = A*log(n)/eps
    z = hxest(q, n, k)
    epsh1 = abs(1/z*(A*log(n) - 2*log(1/(2*p))))
    epsh2 = abs(1/z*(A*log(n) - 2*log(2 - 2*p)))
                                        #tau1 = A*log(n)/epsh1
                                        #epsh = if (z < tau1) epsh1 else epsh2
    list(max=max(epsh1, epsh2), epsh1=epsh1, epsh2=epsh2, hx=z)
  }
  findeh(q=length(unique(data[[ncol(data)]])),
         n=nrow(data), k=k, p=p, eps=eps)
}
######### gamma

gamma = function(data, p=0.95, tau=0.05, B = getOption('pph.B', 0.5), k = NULL) {
  if(is.null(k)) k = defk(data)
  if (k == ncol(data)-1) return(1)
  epsh = heps(data, k=k, p=p)$max
  epsp = peps(data, k=k, tau=tau, B=B)$eps
  epsh/(epsh + epsp)
}
