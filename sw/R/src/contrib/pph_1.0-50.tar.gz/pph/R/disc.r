################################################################################
#
# File:         disc.r
# RCS:          $Header: $
# Description:  
# Author:       Staal Vinterbo
# Created:      Fri Mar 16 16:58:23 2012
# Modified:     Mon Jul  9 16:32:04 2012 (Staal Vinterbo) staal@dink
# Language:     ESS[S]
# Package:      N/A
# Status:       Experimental
#
# (c) Copyright 2012, Staal Vinterbo, all rights reserved.
#
# disc.r is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# disc.r is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with disc.r; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#
################################################################################

#### scale

numcols = function(data)
  names(data)[unlist(Map(is.numeric, as.list(data)))]

v01 = function(v, minv = min(v), maxv = max(v)) (v - minv)/(maxv - minv)
to01 = function(data, warn=FALSE) {
  nc = numcols(data)
  for (n in nc) {
    x = data[[n]]
    if (min(x) < 0 || max(x) > 1){
      if (warn)
        warning(paste('Column', n, 'was scaled into the unit interval!'))
      data[[n]] = v01(data[[n]])
    }
  }
  data
}

##### bandwidth

getbw.fun = function(n,d, minbw=getOption('pph.minbw', 0.1)){
  hn = (log(n)/n)^(1/(1+d))
  k = max(round(1/hn), 2)
  max(1/k, minbw)
}

getbw = function(data) getbw.fun(nrow(data), ncol(data))


#### discretize


vdisc = function(v, bw)
  cut(v, breaks=seq(0,1,bw), labels=FALSE, include.lowest=TRUE)

discretize = function(dat, k=ncol(dat)-1, bw = getbw.fun(nrow(dat), k)){
  disc = function(data, bw=NULL) {
    nc = numcols(data)
    if (length(nc) == 0) 
      return (list(data=data))
    if (is.null(bw)) bw = getbw(data[,nc]) 
    out = data
    breaks=seq(0,1,bw)
    x = 1:(length(breaks) - 1)
    labs = paste((x - 1)*bw + bw/2)

    for (nam in nc){
      x = factor(cut(out[[nam]], breaks=seq(0,1,bw), labels=labs,
        include.lowest=TRUE))
      out[[nam]] = as.numeric(as.vector(x))
    }
    return(list(data=out))
  }
  disc(to01(dat, warn=TRUE), bw)$data
}

