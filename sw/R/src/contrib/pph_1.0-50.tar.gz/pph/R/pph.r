################################################################################
#
# File:         prhist.r
# RCS:          $Header: $
# Description:  
# Author:       Staal Vinterbo
# Created:      Thu Mar 15 20:31:56 2012
# Modified:     Fri Feb  1 10:30:38 2013 (Staal Vinterbo) staal@mats
# Language:     ESS[S]
# Package:      N/A
# Status:       Experimental
#
# (c) Copyright 2012, Staal Vinterbo, all rights reserved.
#
# pph.r is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# pph.r is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with pph.r; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#

################################################################################

#library(hash)
#library(VGAM) # laplace distribution

#source('params.r')
#source('dpkmda.r')

.onLoad = function(libname, pkgname){
  options(pph.minbw = 0.2)
  options(pph.B = 0.5)
  options(pph.A = 0.5)
}

  

prhist = function(data, A=0.5, epsilon=1, data.out=TRUE, verbose=FALSE) {

  tau = A*log(nrow(data))/epsilon

  # helpers
  key = function(v) paste(v, collapse=':')
  unkey = function(k) as.numeric(strsplit(k, ':')[[1]])
  get = function(x) if (is.null(x)) 0 else x
  
  # 1) recode factors as values
  facts = which(unlist(Map(is.factor, as.list(data))))
  flevels = Map(levels, as.list(data[facts]))
  data = as.data.frame(Map(as.numeric, as.list(data)))

  # 2) construct histogram on the data
  hgram = hash()
  inc = function(x, h, by=1) {
    k = key(x)
    h[[k]] = get(h[[k]]) + 1
  }
  apply(data, 1, inc, hgram) # side effects only

  # 3) add the noisy histogram and filter
  ranges = Map(unique, as.list(data))
  store = function(x, h) {
    k = key(x)
    val = h[[k]]
    nval = get(val) + rlaplace(1,scale=2/epsilon)
    if (nval > tau){ # store in hash
      h[[k]] = nval
    } else { # don't store, remove if in hash
      if (!is.null(val)) del(k, h)
    }
  }
  apply(expand.grid(ranges), 1, store, hgram) # side effects only

  if(!data.out) return(hgram)

  # 4) reconstitute the data frame
  out = cbind(values(hgram), Reduce(rbind, Map(unkey, keys(hgram))))
  clear(hgram) # release store
  out = Reduce(rbind, apply(out, 1, function(r) 
    Reduce(rbind, rep(list(r[-1]), round(r[1])))
  ))
  colnames(out) = names(data)
  rownames(out) = c()
  out = data.frame(out)
  ## restore factors...
  if (length(facts) > 0) {
    if (verbose)
      cat('restoring factors', names(data)[facts], '\n')
    for(i in 1:length(facts)) {
      yy = out[[facts[i]]]
      f = factor(flevels[[i]][yy], levels=flevels[[i]])
      out[[facts[i]]] = f
    }
  }
  if (verbose)
    cat('in:', nrow(data), 'out:', nrow(out), 'eps =', epsilon, 'A =', A, '\n')
  out
}
  
# generate private data for learning a target
# rules: columns are either factors or numeric data
#        factors are left alone but numeric data is
#        scaled to [0,1] and the discretized with
#        bw(n, k).

pdata = function(data, target=ncol(data), eps=1, A=getOption('pph.A', 0.5),
  k = defk(data,target=target),
  gamma.=gamma(data,k=k), jitter = NULL, histogram.out=FALSE, verbose=FALSE) {
  
  epsh = eps * gamma.
  epsp = eps * (1 - gamma.)

  if (verbose)
    cat('eps', eps, 'gamma', gamma., 'k', k, 'target',target, 'bw',
        getbw.fun(nrow(data), k), '\n')
  
  #print(target)
  # scale and discretize
  #data.in = data
  # bw = max(getbw.fun(nrow(data), k), 0.2)
  data = discretize(data, k=k)

  #print(data[1:2,])

  if(!is.numeric(target)){
    target = which(names(data) == target)
    if (length(target) < 1 || length(target) > 1)
      stop("Non-exitent or non-unique target", target)
  }
  #print(target)
  # project
  preds = list(S=(1:ncol(data))[-target], lo=NA)
  if (k < ncol(data) - 1) {
    preds = kmda.r(target, as.matrix(data), k, epsilon=epsp, verbose=verbose)
  } else {
    epsh = eps
  }

  # data = discretize(data.in, k=k)
  
  #print(preds)

  # generate projected histogram data
  cols = sort(c(preds$S,target))
  data = prhist(data[,cols], A=A, epsilon=epsh, data.out=!histogram.out, verbose=verbose)

  # add jitter to discretized values to smooth out the data
  if(!is.null(jitter) && jitter > 0) {
    nums = unlist(Map(is.numeric, as.list(data)))
    nums[target] = FALSE # don't jitter target
    nums = which(nums)
    for(i in nums) {
      data[[i]] = base::jitter(data[[i]], factor=jitter)
    }
  }
  data
}
    
  
  


  
  
