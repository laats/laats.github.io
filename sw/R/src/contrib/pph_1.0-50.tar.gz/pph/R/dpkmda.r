################################################################################
#
# File:         dpkmda.r
# RCS:          $Header: $
# Description:  Differentially private k-discernibility. Works only for
#               non-factor data as is.
# Author:       Staal Vinterbo
# Created:      Sun Nov 27 18:23:45 2011
# Modified:     Mon Jul  9 11:43:45 2012 (Staal Vinterbo) staal@dink
# Language:     ESS[S]
# Package:      N/A
# Status:       Experimental
#
# (c) Copyright 2011, Staal Vinterbo, all rights reserved.
#
# dpkmda.r is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# dpkmda.r is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with dpkmda.r; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#
################################################################################

# MDA algorithm helpers


# here Differentially private MDA algorithm, default is epsilon DP
# note f is an index into m
kmda.r = function(f, m, k, epsilon=1, verbose=FALSE){

  partition = function(indexlist, values)
    tapply(indexlist, values, list)

  refine = function(part, attribute)
    unlist(lapply(part, function(il) partition(il, attribute[il])),
           recursive=FALSE)

  pairs = function(h, x = 0, y = 0){
    if (length(h) == 0) return(x)
    n = head(h, 1)
    pairs(tail(h, -1), x + y*n, y + n)
  }

  hist = function(indexlist, values)
    apply(table(indexlist, values), 2, sum)

  leftover = function(part, attribute)
    sum(sapply(part,
               function(il) pairs(hist(il, attribute[il]))))
  
  softmax = function(x) {
    z = exp(x - max(x))
    z/sum(z)
  }
  
  m = as.matrix(m)
  
  non.private = is.na(epsilon) || is.null(epsilon)
  if (verbose)
    cat('kmda: projecting onto ', k,
        'with epsilon = ', epsilon,' privately = ', !non.private, '\n')
  eps = epsilon/k
  # non-private case: nfpairs = pairs(hist(1:nrow(m), f))
  # to ensure epsilon-differential privacy:
  # normalizer is 4*n for ordered pairs, but pairs() counts only unordered, so we need only
  # divide by 2*n since we consider pairs unordered


  # exclude all constant attributes
  exclude = which(apply(m, 2, function(x) length(unique(x)) < 2))
  A = (1:ncol(m))[-c(f, exclude)]
  
  n = nrow(m)
  nfpairs = pairs(hist(1:n, m[,f]))
  
  #print(c('nfpairs', nfpairs/(2*n)))
  
  kmda.rec = function(C, A, S, last.fs){
    if(length(A) == 0 || length(S) == k)
      return(list(S=S, lo=last.fs))

    lovers = sapply(A, function(i) leftover(refine(C, m[,i]), m[,f]))
    FS = pmax(nfpairs - lovers, 0)/(2*n) # normalizer
    
    if (!non.private){
      probs = softmax(eps*(FS - last.fs))
      if (length(probs) == 0)
        stop(paste('kmda: length(probs) == 0', length(probs)))
      a = sample(1:length(lovers), 1, prob=probs)
      #print(c('chose', a, FS[a]))
    }
    else {
      if(verbose) cat('lovers: ', lovers, '\n')
      a = which.min(lovers)
      if(verbose) cat('chose', a, A[a], '\n')
    }
    kmda.rec(refine(C, m[,A[a]]), A[-a], c(S,A[a]), FS[a])
  }
  
  kmda.rec(list(1:nrow(m)), A, c(), 0)
}

kmda = function(object, ...) UseMethod("kmda")

kmda.numeric = function(object, m, k, epsilon=1, verbose=FALSE)
  kmda.r(object, m=m, k=k, epsilon=epsilon, verbose=verbose)

kmda.matrix = function(object, target = ncol(object), ...)
  kmda.r(target, object,...)

kmda.data.frame = function(object, target = ncol(object), ...)
  kmda.r(target, object,...)

kmda.formula = function(object, data=NULL, ...){
  frame = model.frame(object, data)
  S = kmda(frame, 1, ...)
  y = names(frame)[1]
  x = paste(names(frame)[S$S], collapse='+')
  f = as.formula(paste(y, x, sep='~'))
  environment(f) = parent.frame()
  f
}
  
  
