`infa` <-
function (a) 
inf(diag(table(a, a))/length(a))
