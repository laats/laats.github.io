`securelog2` <-
function (x) 
if (x <= 0) return(0) else return(log2(x))
