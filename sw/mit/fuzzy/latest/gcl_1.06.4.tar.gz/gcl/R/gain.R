`gain` <-
function (a, b) 
infa(b) - rema(table(a, b))
